function togglePopup(popupId) {
  const popup = document.getElementById(popupId);
  popup.classList.toggle("open");
}

var form = document.getElementById("equation-popup");

form.addEventListener("submit", function (e) {
  e.preventDefault();
  
});